import java.util.LinkedList;

// --== CS400 File Header Information ==--
// Name: 				Eric Choi
// Email: 				hchoi256@wisc.edu
// Team: 				ID
// TA:		 			Mu Cai
// Lecturer: 			Gary Dahl
// Notes to Grader: 	<optional extra notes>

public class DataWrangling extends Backend {
	private HashTableMap hashTable = new HashTableMap();

	private void init() {
		hashTable.put(1, "Samsung");
		hashTable.put(2, "Apple");
		hashTable.put(3, "Huawei");
		hashTable.put(4, "Xiaomi");
		hashTable.put(5, "Nokia");
		hashTable.put(6, "Sony");
		hashTable.put(7, "HTC");
		hashTable.put(8, "Motoral");
		hashTable.put(9, "Lenovo");
		hashTable.put(10, "Oneplus");
		hashTable.put(11, "Chevrolet");
		hashTable.put(12, "Volkswagen");
		hashTable.put(13, "Toyota");
		hashTable.put(14, "Kia");
		hashTable.put(15, "Hyundai");
		hashTable.put(16, "Toyota");
		hashTable.put(17, "Honda");
		hashTable.put(18, "Mazda");
		hashTable.put(19, "Lamborghini");
		hashTable.put(20, "Porsche");
		hashTable.put(21, "experience");
		hashTable.put(22, "experiment");
		hashTable.put(23, "desert");
		hashTable.put(24, "dessert");
		hashTable.put(25, "lose");
		hashTable.put(26, "loose");
		hashTable.put(27, "principal");
		hashTable.put(28, "principle");
		hashTable.put(29, "sensitive");
		hashTable.put(30, "sensible");
	}

	public void AddData() {
		init(); // put data to this hash table object

		for (int i = 1; i <= hashTable.size(); i++) {
			sendTC(i, hashTable.get(i).toString());
		}

		HashTableMap hashT = getTestCases();

		// getTestCases()
		if (hashT != null && hashT.size() > 0) {
			for (LinkedList<KeyValueClass> iterate : hashT.getList()) {
				if (iterate != null) {
					for (KeyValueClass kvC : iterate) {
						System.out.println(kvC.getKey() + " " + kvC.getValue());
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		DataWrangling dw = new DataWrangling();

		dw.AddData();
	}
}
